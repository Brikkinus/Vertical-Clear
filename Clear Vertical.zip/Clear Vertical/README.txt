Clear Vertical


This is an emulationstation theme I made for vertical screens. Note that this was originally made for 16x10 in mind, I'm not sure how it will behave with other resolution.